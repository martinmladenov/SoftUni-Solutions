namespace SIS.Demo.ViewModels
{
    public class LoginUserViewModel
    {
        public string Username { get; set; }

        public string Password { get; set; }
    }
}